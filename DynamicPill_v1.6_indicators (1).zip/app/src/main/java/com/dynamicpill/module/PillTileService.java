package com.dynamicpill.module;

public class PillTileService extends BaseTile {
    @Override protected String prefKey() { return PillController.K_ENABLED; }
    @Override protected int iconRes() { return R.drawable.ic_pill; }
    @Override protected String tileName() { return "Dynamic Pill"; }
}
